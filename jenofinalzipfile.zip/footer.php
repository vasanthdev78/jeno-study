<footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <center>
                                <p>&copy; Jeno Study Center. All Rights Reserved. <br />Designed and Developed by <a href="#">Roriri Software Solutions Pvt Ltd</a>.</p>
                                </center>
                            </div>
                        </div>
                    </div>
                </footer>